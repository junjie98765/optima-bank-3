import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import mongoose from "mongoose"
import Cart from "@/lib/models/cart"
import Voucher from "@/lib/models/voucher"

// Get user's cart
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await mongoose.connect(process.env.MONGODB_URI as string)

    // Find or create cart
    let cart = await Cart.findOne({ user: session.user.id }).populate("items.voucher")

    if (!cart) {
      cart = new Cart({
        user: session.user.id,
        items: [],
      })
      await cart.save()
    }

    return NextResponse.json(cart)
  } catch (error) {
    console.error("Error fetching cart:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// Add item to cart
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { voucherId, quantity = 1 } = await request.json()

    if (!voucherId) {
      return NextResponse.json({ message: "Voucher ID is required" }, { status: 400 })
    }

    await mongoose.connect(process.env.MONGODB_URI as string)

    // Verify voucher exists
    const voucher = await Voucher.findById(voucherId)

    if (!voucher) {
      return NextResponse.json({ message: "Voucher not found" }, { status: 404 })
    }

    // Find or create cart
    let cart = await Cart.findOne({ user: session.user.id })

    if (!cart) {
      cart = new Cart({
        user: session.user.id,
        items: [],
      })
    }

    // Check if item already exists in cart
    const existingItemIndex = cart.items.findIndex((item: any) => item.voucher.toString() === voucherId)

    if (existingItemIndex > -1) {
      // Update quantity if item exists
      cart.items[existingItemIndex].quantity += quantity
    } else {
      // Add new item if it doesn't exist
      cart.items.push({
        voucher: voucherId,
        quantity,
      })
    }

    cart.updatedAt = new Date()
    await cart.save()

    return NextResponse.json(cart)
  } catch (error) {
    console.error("Error adding to cart:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// Update cart item
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { itemId, quantity } = await request.json()

    if (!itemId || !quantity) {
      return NextResponse.json({ message: "Item ID and quantity are required" }, { status: 400 })
    }

    if (quantity < 1) {
      return NextResponse.json({ message: "Quantity must be at least 1" }, { status: 400 })
    }

    await mongoose.connect(process.env.MONGODB_URI as string)

    const cart = await Cart.findOne({ user: session.user.id })

    if (!cart) {
      return NextResponse.json({ message: "Cart not found" }, { status: 404 })
    }

    const itemIndex = cart.items.findIndex((item: any) => item._id.toString() === itemId)

    if (itemIndex === -1) {
      return NextResponse.json({ message: "Item not found in cart" }, { status: 404 })
    }

    cart.items[itemIndex].quantity = quantity
    cart.updatedAt = new Date()
    await cart.save()

    return NextResponse.json(cart)
  } catch (error) {
    console.error("Error updating cart:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// Remove item from cart
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const itemId = searchParams.get("itemId")

    if (!itemId) {
      return NextResponse.json({ message: "Item ID is required" }, { status: 400 })
    }

    await mongoose.connect(process.env.MONGODB_URI as string)

    const cart = await Cart.findOne({ user: session.user.id })

    if (!cart) {
      return NextResponse.json({ message: "Cart not found" }, { status: 404 })
    }

    cart.items = cart.items.filter((item: any) => item._id.toString() !== itemId)

    cart.updatedAt = new Date()
    await cart.save()

    return NextResponse.json(cart)
  } catch (error) {
    console.error("Error removing from cart:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
