import Link from "next/link"
import type { Metadata } from "next"
import LoginForm from "./login-form"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export const metadata: Metadata = {
  title: "Login - Optima Rewards",
  description: "Login to your Optima Rewards account",
}

export default function LoginPage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-1 flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full bg-white p-8 rounded-lg shadow-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Login Here</h1>
          </div>

          <LoginForm />

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Don't have an account?{" "}
              <Link href="/signup" className="text-primary hover:text-primary/90 font-medium">
                Sign up here
              </Link>
            </p>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
