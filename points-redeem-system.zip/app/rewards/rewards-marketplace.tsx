"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, RefreshCw } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

type Voucher = {
  _id: string
  name: string
  description: string
  points: number
  category: string
  validUntil: string
  image?: string
}

interface RewardsMarketplaceProps {
  vouchers: Voucher[]
  userPoints: number
}

export default function RewardsMarketplace({ vouchers = [], userPoints = 0 }: RewardsMarketplaceProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All Categories")

  const categories = ["All Categories", "Food & Dining", "Shopping", "Travel", "Entertainment", "Other"]

  const filteredVouchers = vouchers.filter((voucher) => {
    const matchesSearch =
      voucher.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      voucher.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "All Categories" || voucher.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  // If no vouchers are provided, show placeholders
  const placeholderVouchers = [
    {
      _id: "1",
      name: "Starbucks Gift Card",
      description: "Enjoy a cup of premium coffee at any Starbucks outlet nationwide.",
      points: 500,
      category: "Food & Dining",
      validUntil: "Dec 31, 2023",
    },
    {
      _id: "2",
      name: "Amazon $25 Gift Card",
      description: "Shop your favorite items on Amazon with this digital gift card.",
      points: 750,
      category: "Shopping",
      validUntil: "Dec 31, 2023",
    },
    {
      _id: "3",
      name: "Movie Ticket Voucher",
      description: "Get a free movie ticket at any participating cinema.",
      points: 400,
      category: "Entertainment",
      validUntil: "Nov 30, 2023",
    },
  ]

  const displayVouchers = vouchers.length > 0 ? filteredVouchers : placeholderVouchers

  return (
    <div className="flex-1 bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="bg-secondary text-white p-8 rounded-lg mb-8">
          <h1 className="text-3xl font-bold mb-4">Rewards Marketplace</h1>
          <p className="text-lg">
            Redeem your points for exclusive rewards, discounts, and vouchers from our partner brands.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Your Rewards Journey</h2>
          <div className="flex items-center justify-end mb-2">
            <Button variant="ghost" size="sm" className="flex items-center text-gray-500">
              <RefreshCw className="h-4 w-4 mr-1" />
              <span>Refresh</span>
            </Button>
          </div>
          <p className="text-sm text-gray-600 mb-2">
            Keep earning points to unlock premium rewards and exclusive offers.
          </p>
          <Progress value={(userPoints / 1000) * 100} className="h-2 mb-2" />
          <div className="flex justify-between text-sm text-gray-600">
            <span>0 points</span>
            <span className="font-medium">{userPoints} points</span>
            <span>1,000 points</span>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                type="text"
                placeholder="Search for rewards..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Badge
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  className={`cursor-pointer ${
                    selectedCategory === category ? "bg-primary hover:bg-primary/90" : "hover:bg-gray-100"
                  }`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayVouchers.map((voucher) => (
              <div
                key={voucher._id}
                className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
              >
                <div className="p-4 bg-orange-100 flex items-center justify-center h-48">
                  <img
                    src={voucher.image || `/placeholder.svg?height=150&width=150`}
                    alt={voucher.name}
                    className="h-32 object-contain"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-xl font-semibold">{voucher.name}</h3>
                    <span className="text-primary font-bold">{voucher.points} points</span>
                  </div>
                  <p className="text-gray-600 mb-4">{voucher.description}</p>
                  <p className="text-sm text-gray-500 mb-4">Valid until: {voucher.validUntil}</p>

                  <div className="flex flex-col space-y-2">
                    <Button
                      className={`w-full ${
                        userPoints >= voucher.points
                          ? "bg-primary hover:bg-primary/90"
                          : "bg-gray-300 cursor-not-allowed"
                      }`}
                      disabled={userPoints < voucher.points}
                    >
                      Redeem Now
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        // Add to cart functionality will be implemented later
                        alert("Added to cart!")
                      }}
                    >
                      Add to Cart
                    </Button>
                  </div>

                  <div className="mt-4 text-xs text-center">
                    <Link href={`/rewards/${voucher._id}/terms`} className="text-primary hover:underline">
                      View Terms & Conditions
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
