import type { Metadata } from "next"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import RewardsMarketplace from "./rewards-marketplace"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { connectToDatabase } from "@/lib/db"

export const metadata: Metadata = {
  title: "Rewards Marketplace - Optima Rewards",
  description: "Browse and redeem your points for exclusive rewards",
}

async function getVouchers() {
  try {
    const { db } = await connectToDatabase()
    const vouchers = await db.collection("vouchers").find({}).toArray()
    return JSON.parse(JSON.stringify(vouchers))
  } catch (error) {
    console.error("Failed to fetch vouchers:", error)
    return []
  }
}

export default async function RewardsPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  const vouchers = await getVouchers()

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <RewardsMarketplace vouchers={vouchers} userPoints={session.user.points} />

      <Footer />
    </main>
  )
}
