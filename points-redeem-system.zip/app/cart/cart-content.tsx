"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Minus, Plus, Trash2, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

type CartItem = {
  _id: string
  voucher: {
    _id: string
    name: string
    description: string
    points: number
    validUntil: string
  }
  quantity: number
}

interface CartContentProps {
  cart: {
    items: CartItem[]
  }
  userPoints: number
}

export default function CartContent({ cart = { items: [] }, userPoints = 0 }: CartContentProps) {
  const router = useRouter()
  const [items, setItems] = useState(
    cart.items.length > 0
      ? cart.items
      : [
          {
            _id: "1",
            voucher: {
              _id: "2",
              name: "Amazon $25 Gift Card",
              description: "Shop your favorite items on Amazon with this digital gift card.",
              points: 750,
              validUntil: "Dec 31, 2023",
            },
            quantity: 1,
          },
        ],
  )

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)
  const totalPoints = items.reduce((sum, item) => sum + item.voucher.points * item.quantity, 0)
  const canCheckout = userPoints >= totalPoints

  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return

    setItems(items.map((item) => (item._id === itemId ? { ...item, quantity: newQuantity } : item)))
  }

  const removeItem = (itemId: string) => {
    setItems(items.filter((item) => item._id !== itemId))
  }

  const clearCart = () => {
    setItems([])
  }

  const handleCheckout = () => {
    if (!canCheckout) {
      alert("You do not have enough points to complete this purchase.")
      return
    }

    // In a real application, this would call an API to process the checkout
    alert("Checkout successful! Your vouchers have been redeemed.")
    setItems([])
  }

  return (
    <div className="flex-1 bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-purple-900 mb-8">Your Cart</h1>

        {items.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6 border-b">
                  <h2 className="text-xl font-semibold">Cart Items</h2>
                  <div className="text-sm text-gray-500">{totalItems} item(s)</div>
                </div>

                {items.map((item) => (
                  <div key={item._id} className="p-6 border-b">
                    <div className="flex flex-col md:flex-row gap-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-primary">{item.voucher.name}</h3>
                        <p className="text-gray-600 text-sm mb-2">{item.voucher.description}</p>
                        <p className="text-sm text-gray-500">Valid until: {item.voucher.validUntil}</p>
                      </div>

                      <div className="flex flex-col items-end">
                        <div className="text-primary font-bold mb-2">{item.voucher.points} points</div>

                        <div className="flex items-center mb-2">
                          <button
                            className="p-1 rounded-full bg-gray-100 hover:bg-gray-200"
                            onClick={() => updateQuantity(item._id, item.quantity - 1)}
                          >
                            <Minus className="h-4 w-4" />
                          </button>

                          <span className="mx-3">{item.quantity}</span>

                          <button
                            className="p-1 rounded-full bg-gray-100 hover:bg-gray-200"
                            onClick={() => updateQuantity(item._id, item.quantity + 1)}
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>

                        <div className="text-gray-700 font-medium mb-2">
                          {item.voucher.points * item.quantity} points
                        </div>

                        <button
                          className="text-red-500 hover:text-red-700 flex items-center text-sm"
                          onClick={() => removeItem(item._id)}
                        >
                          <Trash2 className="h-4 w-4 mr-1" /> Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 flex justify-between">
                <Button variant="outline" className="flex items-center" onClick={() => router.push("/rewards")}>
                  <ArrowLeft className="h-4 w-4 mr-2" /> Continue Shopping
                </Button>

                <Button
                  variant="outline"
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  onClick={clearCart}
                >
                  <Trash2 className="h-4 w-4 mr-2" /> Clear Cart
                </Button>
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="bg-white rounded-lg shadow-md overflow-hidden sticky top-4">
                <div className="p-6 border-b">
                  <h2 className="text-xl font-semibold">Order Summary</h2>
                </div>

                <div className="p-6">
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Total Items</span>
                      <span>{totalItems}</span>
                    </div>

                    <div className="flex justify-between font-bold text-lg">
                      <span>Total Points</span>
                      <span>{totalPoints}</span>
                    </div>

                    <div className="pt-4 border-t">
                      <Button
                        className={`w-full ${canCheckout ? "bg-primary hover:bg-primary/90" : "bg-gray-300 cursor-not-allowed"}`}
                        disabled={!canCheckout}
                        onClick={handleCheckout}
                      >
                        Checkout
                      </Button>

                      {!canCheckout && (
                        <p className="text-red-500 text-sm mt-2">
                          You need {totalPoints - userPoints} more points to complete this purchase.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <h2 className="text-2xl font-semibold mb-4">Your cart is empty</h2>
            <p className="text-gray-600 mb-6">Looks like you haven't added any rewards to your cart yet.</p>
            <Button asChild className="bg-primary hover:bg-primary/90">
              <Link href="/rewards">Browse Rewards</Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
