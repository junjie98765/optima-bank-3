import type { Metadata } from "next"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import CartContent from "./cart-content"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { connectToDatabase } from "@/lib/db"

export const metadata: Metadata = {
  title: "Your Cart - Optima Rewards",
  description: "View and manage your cart items",
}

async function getUserCart(userId: string) {
  try {
    const { db } = await connectToDatabase()
    const cart = await db.collection("carts").findOne({ user: userId })

    if (!cart) {
      return { items: [] }
    }

    // Populate voucher details
    const cartWithVouchers = {
      ...cart,
      items: await Promise.all(
        cart.items.map(async (item: any) => {
          const voucher = await db.collection("vouchers").findOne({ _id: item.voucher })
          return {
            ...item,
            voucher,
          }
        }),
      ),
    }

    return JSON.parse(JSON.stringify(cartWithVouchers))
  } catch (error) {
    console.error("Failed to fetch cart:", error)
    return { items: [] }
  }
}

export default async function CartPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  const cart = await getUserCart(session.user.id)

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <CartContent cart={cart} userPoints={session.user.points} />

      <Footer />
    </main>
  )
}
