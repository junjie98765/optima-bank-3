import Link from "next/link"
import { ShoppingCart, Bell, User } from "lucide-react"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"

export default async function Navbar() {
  const session = await getServerSession(authOptions)

  return (
    <header className="bg-white shadow-sm py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <span className="text-2xl font-bold text-primary">Optima</span>
          <span className="text-2xl ml-1">Rewards</span>
        </Link>

        <nav className="hidden md:flex space-x-6">
          <Link href="/" className="text-gray-800 hover:text-primary">
            Home
          </Link>
          <Link href="/rewards" className="text-gray-800 hover:text-primary">
            Rewards
          </Link>
          <Link href="/transactions" className="text-gray-800 hover:text-primary">
            Transactions
          </Link>
          <Link href="/support" className="text-gray-800 hover:text-primary">
            Support
          </Link>
        </nav>

        <div className="flex items-center space-x-4">
          {session ? (
            <>
              <div className="flex items-center text-gray-700">
                <span className="mr-1">{session.user.points}</span>
                <span>Points</span>
              </div>
              <Link href="/notifications" className="text-gray-700 hover:text-primary">
                <Bell className="h-6 w-6" />
              </Link>
              <Link href="/cart" className="text-gray-700 hover:text-primary relative">
                <ShoppingCart className="h-6 w-6" />
                <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  1
                </span>
              </Link>
              <Link href="/profile" className="text-gray-700 hover:text-primary">
                <User className="h-6 w-6" />
              </Link>
            </>
          ) : (
            <Link href="/login" className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-md">
              Login
            </Link>
          )}
        </div>
      </div>
    </header>
  )
}
